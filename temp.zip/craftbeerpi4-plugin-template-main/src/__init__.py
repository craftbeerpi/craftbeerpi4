import os

def setup(cbpi):
    print("###### SETUP PLUGIN #####")
    
